'use strict';

/*
 * storage.js — хранение настроек, закладок и пользовательских шрифтов.
 * Общий модуль для newtab.js и settings.js. Всё лежит в chrome.storage.local,
 * внешних серверов нет.
 */
(function (global) {
  const SETTINGS_KEY = 'settings';
  const FONTS_KEY = 'customFonts';

  const SYSTEM_STACK = "system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif";

  /** Встроенные шрифты (лежат в assets/fonts, работают офлайн). */
  const BUILTIN_FONTS = [
    { id: 'builtin:inter', label: 'Inter', family: "'Inter Variable'" },
    { id: 'builtin:manrope', label: 'Manrope', family: "'Manrope Variable'" },
    { id: 'builtin:montserrat', label: 'Montserrat', family: "'Montserrat Variable'" },
    { id: 'builtin:outfit', label: 'Outfit', family: "'Outfit Variable'" },
    { id: 'builtin:space-grotesk', label: 'Space Grotesk', family: "'Space Grotesk Variable'" },
    { id: 'builtin:jetbrains-mono', label: 'JetBrains Mono', family: "'JetBrains Mono Variable'" },
    { id: 'system', label: 'Системный', family: null }
  ];

  const DEFAULTS = {
    clock: {
      fontId: 'builtin:inter',
      size: 180,
      weight: 200,
      letterSpacing: 0,
      color: '#f2f2f2',
      format: '24',
      showSeconds: false,
      showDate: false,
      dateSize: 24
    },
    shadow: { enabled: false, color: '#000000', opacity: 40, blur: 24, x: 0, y: 6 },
    position: { mode: 'center', offsetX: 0, offsetY: 0, manualX: 50, manualY: 45 },
    background: { color: '#111214' },
    bookmarks: {
      fontSize: 15,
      color: '#f2f2f2',
      opacity: 55,
      gap: 28,
      weight: 400,
      sameFont: true,
      align: 'center'
    },
    items: []
  };

  const clone = (o) => JSON.parse(JSON.stringify(o));

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  // ---------- цвет ----------

  /** Принимает HEX (#abc, #aabbcc) или RGB (rgb(1,2,3), "1,2,3", "1 2 3"). Возвращает '#rrggbb' или null. */
  function parseColor(input) {
    if (typeof input !== 'string') return null;
    const v = input.trim().toLowerCase();
    if (!v) return null;
    let m = v.match(/^#?([0-9a-f]{3})$/);
    if (m) {
      const [a, b, c] = m[1];
      return '#' + a + a + b + b + c + c;
    }
    m = v.match(/^#?([0-9a-f]{6})$/);
    if (m) return '#' + m[1];
    m = v.match(/^(?:rgb\(\s*)?(\d{1,3})\s*[,\s]\s*(\d{1,3})\s*[,\s]\s*(\d{1,3})\s*\)?$/);
    if (m) {
      const n = [m[1], m[2], m[3]].map(Number);
      if (n.every((x) => x >= 0 && x <= 255)) {
        return '#' + n.map((x) => x.toString(16).padStart(2, '0')).join('');
      }
    }
    return null;
  }

  function hexToRgb(hex) {
    const h = parseColor(hex) || '#000000';
    return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
  }

  function rgba(hex, alpha) {
    const [r, g, b] = hexToRgb(hex);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }

  // ---------- URL ----------

  /** Возвращает нормализованный http(s)-адрес или null, если адрес некорректен. */
  function normalizeUrl(input) {
    let v = String(input || '').trim();
    if (!v || /\s/.test(v)) return null;
    if (!/^https?:\/\//i.test(v)) {
      // любая другая схема (javascript:, data:, file:, mailto: …) запрещена; "host:3000" — не схема
      if (/^[a-z][a-z0-9+.-]*:(?!\d)/i.test(v)) return null;
      v = 'https://' + v.replace(/^\/\//, '');
    }
    let u;
    try {
      u = new URL(v);
    } catch (e) {
      return null;
    }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    const host = u.hostname;
    const looksValid = host.includes('.') || host === 'localhost' || host.startsWith('[');
    if (!host || !looksValid) return null;
    return u.href;
  }

  function hostnameOf(url) {
    try {
      return new URL(url).hostname.replace(/^www\./, '');
    } catch (e) {
      return url;
    }
  }

  // ---------- нормализация настроек ----------

  function merge(base, over) {
    if (Array.isArray(base)) return Array.isArray(over) ? over : clone(base);
    if (base && typeof base === 'object') {
      const out = {};
      for (const k of Object.keys(base)) {
        const has = over && typeof over === 'object' && !Array.isArray(over) && k in over;
        out[k] = has ? merge(base[k], over[k]) : clone(base[k]);
      }
      return out;
    }
    if (typeof base === 'number') return Number.isFinite(over) ? over : base;
    return typeof over === typeof base ? over : base;
  }

  function normalizeSettings(raw) {
    const s = merge(DEFAULTS, raw);
    for (const sect of ['clock', 'shadow', 'background', 'bookmarks']) {
      for (const k of Object.keys(s[sect])) {
        if (/color$/i.test(k)) s[sect][k] = parseColor(s[sect][k]) || DEFAULTS[sect][k];
      }
    }
    s.items = s.items
      .filter((it) => it && typeof it.id === 'string' && typeof it.url === 'string' && normalizeUrl(it.url))
      .map((it) => ({
        id: it.id,
        title: String(it.title || hostnameOf(it.url)).slice(0, 60),
        url: it.url,
        color: it.color ? parseColor(it.color) || '' : ''
      }));
    return s;
  }

  // ---------- доступ к storage ----------

  async function getSettings() {
    const r = await chrome.storage.local.get(SETTINGS_KEY);
    return normalizeSettings(r[SETTINGS_KEY]);
  }

  // Все записи идут через одну очередь, чтобы быстрые изменения (ползунки) не затирали друг друга.
  let queue = Promise.resolve();
  function update(mutator) {
    const run = queue.then(async () => {
      const current = await getSettings();
      const result = mutator(current);
      const next = normalizeSettings(result === undefined ? current : result);
      await chrome.storage.local.set({ [SETTINGS_KEY]: next });
      return next;
    });
    queue = run.catch(() => {});
    return run;
  }

  function setByPath(obj, path, value) {
    const keys = path.split('.');
    let o = obj;
    for (let i = 0; i < keys.length - 1; i++) o = o[keys[i]];
    o[keys[keys.length - 1]] = value;
  }

  function getByPath(obj, path) {
    return path.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
  }

  function setPath(path, value) {
    return update((s) => {
      setByPath(s, path, value);
    });
  }

  /** Сброс отдельных разделов настроек к значениям по умолчанию, остальное не трогаем. */
  function resetKeys(keys) {
    return update((s) => {
      keys.forEach((k) => {
        s[k] = clone(DEFAULTS[k]);
      });
    });
  }

  /** Полный сброс. Закладки и шрифты удаляются только по явному выбору. */
  async function resetAll({ bookmarks = false, fonts = false } = {}) {
    await update((s) => {
      const fresh = clone(DEFAULTS);
      if (!bookmarks) fresh.items = s.items;
      return fresh;
    });
    if (fonts) await chrome.storage.local.remove(FONTS_KEY);
  }

  // ---------- закладки ----------

  function saveBookmark({ id, title, url, color }) {
    const clean = normalizeUrl(url);
    if (!clean) return Promise.reject(new Error('bad-url'));
    return update((s) => {
      const item = {
        id: id || uid(),
        title: (title || '').trim() || hostnameOf(clean),
        url: clean,
        color: color || ''
      };
      const idx = id ? s.items.findIndex((i) => i.id === id) : -1;
      if (idx >= 0) s.items[idx] = item;
      else s.items.push(item);
    });
  }

  function deleteBookmark(id) {
    return update((s) => {
      s.items = s.items.filter((i) => i.id !== id);
    });
  }

  function moveBookmark(id, toIndex) {
    return update((s) => {
      const from = s.items.findIndex((i) => i.id === id);
      if (from < 0 || toIndex < 0 || toIndex >= s.items.length) return;
      const [it] = s.items.splice(from, 1);
      s.items.splice(toIndex, 0, it);
    });
  }

  // ---------- шрифты ----------

  async function getFonts() {
    const r = await chrome.storage.local.get(FONTS_KEY);
    const v = r[FONTS_KEY];
    return v && typeof v === 'object' ? v : {};
  }

  let fontQueue = Promise.resolve();
  function fontOp(fn) {
    const run = fontQueue.then(fn);
    fontQueue = run.catch(() => {});
    return run;
  }

  function addFont({ name, format, data, size }) {
    return fontOp(async () => {
      const fonts = await getFonts();
      const id = uid();
      fonts[id] = { id, name, format, data, size };
      await chrome.storage.local.set({ [FONTS_KEY]: fonts });
      return id;
    });
  }

  function removeFont(id) {
    return fontOp(async () => {
      const fonts = await getFonts();
      delete fonts[id];
      await chrome.storage.local.set({ [FONTS_KEY]: fonts });
      await update((s) => {
        if (s.clock.fontId === 'custom:' + id) s.clock.fontId = DEFAULTS.clock.fontId;
      });
    });
  }

  function customFamily(id) {
    return 'MSCustom-' + id;
  }

  /** CSS font-family для идентификатора шрифта (с запасными системными). */
  function fontStack(fontId) {
    if (typeof fontId === 'string' && fontId.startsWith('custom:')) {
      return `'${customFamily(fontId.slice(7))}', ${SYSTEM_STACK}`;
    }
    const b = BUILTIN_FONTS.find((f) => f.id === fontId);
    return b && b.family ? `${b.family}, ${SYSTEM_STACK}` : SYSTEM_STACK;
  }

  function onChange(cb) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && (changes[SETTINGS_KEY] || changes[FONTS_KEY])) cb(changes);
    });
  }

  global.Store = {
    SETTINGS_KEY,
    FONTS_KEY,
    SYSTEM_STACK,
    BUILTIN_FONTS,
    DEFAULTS,
    clone,
    uid,
    parseColor,
    hexToRgb,
    rgba,
    normalizeUrl,
    hostnameOf,
    normalizeSettings,
    getSettings,
    update,
    setPath,
    getByPath,
    setByPath,
    resetKeys,
    resetAll,
    saveBookmark,
    deleteBookmark,
    moveBookmark,
    getFonts,
    addFont,
    removeFont,
    customFamily,
    fontStack,
    onChange
  };
})(typeof window !== 'undefined' ? window : globalThis);
