'use strict';

(function () {
  const isPreview = new URLSearchParams(location.search).has('preview');
  if (isPreview) document.documentElement.classList.add('preview');

  const $ = (id) => document.getElementById(id);
  const root = document.documentElement;
  const timeEl = $('time');
  const ampmEl = $('ampm');
  const dateEl = $('date');
  const listEl = $('bookmarks');

  let settings = Store.normalizeSettings(null);
  let fonts = {};
  const fontLoads = new Map(); // id -> Promise<boolean>
  let renderedItemsKey = '';
  let timer = null;
  let lastTime = '';
  let lastDate = '';
  let applySeq = 0;

  // ---------- шрифты ----------

  function ensureCustomFont(id) {
    if (fontLoads.has(id)) return fontLoads.get(id);
    const f = fonts[id];
    const p = (async () => {
      if (!f || !f.data || typeof FontFace === 'undefined') return false;
      try {
        // диапазон 100–900: браузер не будет «жирнить» обычное начертание искусственно
        const face = new FontFace(Store.customFamily(id), `url("${f.data}")`, {
          weight: '100 900',
          style: 'normal'
        });
        await face.load();
        document.fonts.add(face);
        return true;
      } catch (e) {
        console.warn('Не удалось загрузить пользовательский шрифт', f && f.name, e);
        return false;
      }
    })();
    fontLoads.set(id, p);
    return p;
  }

  async function resolveFontStack(fontId) {
    if (typeof fontId === 'string' && fontId.startsWith('custom:')) {
      const ok = await ensureCustomFont(fontId.slice(7));
      return ok ? Store.fontStack(fontId) : Store.SYSTEM_STACK;
    }
    return Store.fontStack(fontId);
  }

  // ---------- применение настроек ----------

  async function apply() {
    const seq = ++applySeq;
    const c = settings.clock;
    const sh = settings.shadow;
    const p = settings.position;
    const b = settings.bookmarks;
    const st = root.style;

    st.backgroundColor = settings.background.color;
    try {
      localStorage.setItem('ms-bg', settings.background.color);
    } catch (e) {}

    st.setProperty('--clock-size', c.size + 'px');
    st.setProperty('--clock-weight', String(c.weight));
    st.setProperty('--clock-ls', c.letterSpacing + 'em');
    st.setProperty('--clock-color', c.color);
    st.setProperty('--date-size', c.dateSize + 'px');
    st.setProperty(
      '--clock-shadow',
      sh.enabled ? `${sh.x}px ${sh.y}px ${sh.blur}px ${Store.rgba(sh.color, sh.opacity / 100)}` : 'none'
    );

    // примерная ширина строки времени в em — чтобы длинные часы не вылезали за экран
    const chars = c.showSeconds ? 8 : 5;
    const fit = chars * (0.62 + Math.max(c.letterSpacing, 0)) + (c.format === '12' ? 0.9 : 0);
    st.setProperty('--fit', fit.toFixed(2));

    const x = p.mode === 'manual' ? p.manualX : 50 + p.offsetX;
    const y = p.mode === 'manual' ? p.manualY : 50 + p.offsetY;
    st.setProperty('--pos-x', x + '%');
    st.setProperty('--pos-y', y + '%');

    st.setProperty('--bm-size', b.fontSize + 'px');
    st.setProperty('--bm-color', b.color);
    st.setProperty('--bm-opacity', String(b.opacity / 100));
    st.setProperty('--bm-gap', b.gap + 'px');
    st.setProperty('--bm-weight', String(b.weight));
    st.setProperty('--bm-align', { left: 'flex-start', right: 'flex-end' }[b.align] || 'center');

    renderBookmarks();
    restartClock();

    // шрифт ставим после загрузки, чтобы не было «прыжка» из запасного шрифта
    const stack = await resolveFontStack(c.fontId);
    if (seq !== applySeq) return;
    st.setProperty('--clock-font', stack);
    st.setProperty('--bm-font', b.sameFont ? stack : Store.SYSTEM_STACK);
    document.body.classList.add('ready');
  }

  // ---------- часы ----------

  const pad = (n) => String(n).padStart(2, '0');

  function renderClock() {
    const c = settings.clock;
    const now = new Date();
    let h = now.getHours();
    let suffix = '';
    if (c.format === '12') {
      suffix = h >= 12 ? 'PM' : 'AM';
      h = h % 12 || 12;
    } else {
      h = pad(h);
    }
    const text = `${h}:${pad(now.getMinutes())}` + (c.showSeconds ? `:${pad(now.getSeconds())}` : '');
    if (text !== lastTime) {
      timeEl.textContent = text;
      lastTime = text;
    }
    ampmEl.hidden = !suffix;
    if (suffix) ampmEl.textContent = suffix;

    dateEl.hidden = !c.showDate;
    if (c.showDate) {
      let s;
      try {
        s = new Intl.DateTimeFormat(navigator.language || 'ru', {
          weekday: 'long',
          day: 'numeric',
          month: 'long'
        }).format(now);
      } catch (e) {
        s = now.toLocaleDateString();
      }
      s = s.charAt(0).toLocaleUpperCase() + s.slice(1);
      if (s !== lastDate) {
        dateEl.textContent = s;
        lastDate = s;
      }
    }
  }

  function tick() {
    renderClock();
    // следующий тик — ровно на границе секунды/минуты, без лишних пробуждений
    const step = settings.clock.showSeconds ? 1000 : 60000;
    timer = setTimeout(tick, step - (Date.now() % step) + 15);
  }

  function restartClock() {
    clearTimeout(timer);
    tick();
  }

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) restartClock();
  });

  // ---------- закладки ----------

  let dragId = null;

  function renderBookmarks() {
    const key = JSON.stringify(settings.items);
    if (key === renderedItemsKey) return;
    renderedItemsKey = key;
    listEl.replaceChildren();
    settings.items.forEach((item) => {
      const a = document.createElement('a');
      a.className = 'bm';
      a.href = item.url;
      a.textContent = item.title;
      a.title = item.url;
      a.dataset.id = item.id;
      a.rel = 'noopener';
      if (item.color) a.style.setProperty('--bm-item-color', item.color);

      if (!isPreview) {
        a.draggable = true;
        a.addEventListener('dragstart', (e) => {
          dragId = item.id;
          e.dataTransfer.effectAllowed = 'move';
          e.dataTransfer.setData('text/plain', item.id);
          a.classList.add('dragging');
        });
        a.addEventListener('dragend', () => {
          dragId = null;
          listEl.querySelectorAll('.dragging, .drop-target').forEach((n) => n.classList.remove('dragging', 'drop-target'));
        });
        a.addEventListener('dragover', (e) => {
          if (!dragId || dragId === item.id) return;
          e.preventDefault();
          a.classList.add('drop-target');
        });
        a.addEventListener('dragleave', () => a.classList.remove('drop-target'));
        a.addEventListener('drop', (e) => {
          e.preventDefault();
          const from = dragId;
          dragId = null;
          if (!from || from === item.id) return;
          const to = settings.items.findIndex((i) => i.id === item.id);
          Store.moveBookmark(from, to);
        });
        a.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          openContextMenu(item, e.clientX, e.clientY);
        });
      }
      listEl.appendChild(a);
    });
  }

  // ---------- контекстное меню ----------

  const ctx = $('ctx');
  let ctxItem = null;

  function openContextMenu(item, x, y) {
    ctxItem = item;
    ctx.hidden = false;
    const w = ctx.offsetWidth;
    const h = ctx.offsetHeight;
    ctx.style.left = Math.min(x, window.innerWidth - w - 8) + 'px';
    ctx.style.top = Math.min(y, window.innerHeight - h - 8) + 'px';
    ctx.querySelector('button').focus();
  }

  function closeContextMenu() {
    ctx.hidden = true;
    ctxItem = null;
  }

  ctx.addEventListener('click', (e) => {
    const act = e.target.closest('button') && e.target.closest('button').dataset.act;
    const item = ctxItem;
    closeContextMenu();
    if (!item || !act) return;
    if (act === 'edit') openDialog(item);
    if (act === 'delete' && confirm(`Удалить закладку «${item.title}»?`)) Store.deleteBookmark(item.id);
  });
  document.addEventListener('click', (e) => {
    if (!ctx.hidden && !ctx.contains(e.target)) closeContextMenu();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeContextMenu();
  });
  window.addEventListener('blur', closeContextMenu);

  // ---------- модальное окно закладки ----------

  const dlg = $('bm-dialog');
  const form = $('bm-form');
  const fTitle = $('bm-title');
  const fUrl = $('bm-url');
  const fUseColor = $('bm-use-color');
  const fColor = $('bm-color');
  const fError = $('bm-error');
  const fDelete = $('bm-delete');
  let editingId = null;

  function showError(msg) {
    fError.textContent = msg || '';
    fError.hidden = !msg;
  }

  function openDialog(item) {
    editingId = item ? item.id : null;
    $('bm-dialog-title').textContent = item ? 'Изменить закладку' : 'Новая закладка';
    fTitle.value = item ? item.title : '';
    fUrl.value = item ? item.url : '';
    fUseColor.checked = !!(item && item.color);
    fColor.value = (item && item.color) || settings.bookmarks.color;
    fColor.disabled = !fUseColor.checked;
    fDelete.hidden = !item;
    fDelete.textContent = 'Удалить';
    showError('');
    if (typeof dlg.showModal === 'function') dlg.showModal();
    else dlg.setAttribute('open', '');
    fUrl.focus();
    fUrl.select();
  }

  function closeDialog() {
    if (typeof dlg.close === 'function') dlg.close();
    else dlg.removeAttribute('open');
  }

  fUseColor.addEventListener('change', () => {
    fColor.disabled = !fUseColor.checked;
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const url = Store.normalizeUrl(fUrl.value);
    if (!url) {
      showError('Введите корректный адрес, например example.com или https://example.com');
      fUrl.focus();
      return;
    }
    const dup = settings.items.find((i) => i.url === url && i.id !== editingId);
    if (dup) {
      showError(`Такая закладка уже есть: «${dup.title}»`);
      return;
    }
    try {
      await Store.saveBookmark({
        id: editingId,
        title: fTitle.value,
        url,
        color: fUseColor.checked ? fColor.value : ''
      });
      closeDialog();
    } catch (err) {
      showError('Не удалось сохранить закладку. Попробуйте ещё раз.');
      console.error(err);
    }
  });

  $('bm-cancel').addEventListener('click', closeDialog);
  dlg.addEventListener('click', (e) => {
    if (e.target === dlg) closeDialog(); // клик по затемнению
  });

  let deleteArmed = false;
  fDelete.addEventListener('click', async () => {
    if (!editingId) return;
    if (!deleteArmed) {
      deleteArmed = true;
      fDelete.textContent = 'Точно удалить?';
      setTimeout(() => {
        deleteArmed = false;
        fDelete.textContent = 'Удалить';
      }, 3000);
      return;
    }
    deleteArmed = false;
    await Store.deleteBookmark(editingId);
    closeDialog();
  });

  $('add-btn').addEventListener('click', () => openDialog(null));
  $('settings-btn').addEventListener('click', () => chrome.runtime.openOptionsPage());

  // ---------- запуск и синхронизация между вкладками ----------

  Store.onChange(async (changes) => {
    if (changes[Store.FONTS_KEY]) {
      fonts = await Store.getFonts();
      fontLoads.clear();
    }
    if (changes[Store.SETTINGS_KEY]) {
      settings = Store.normalizeSettings(changes[Store.SETTINGS_KEY].newValue);
    }
    apply();
  });

  (async function init() {
    try {
      [settings, fonts] = await Promise.all([Store.getSettings(), Store.getFonts()]);
    } catch (e) {
      console.error('Не удалось прочитать настройки, используются значения по умолчанию', e);
    }
    await apply();
  })();
})();
