'use strict';

// Выполняется до отрисовки: подставляет последний цвет фона (без белой вспышки)
// и страхует показ страницы, если основной скрипт по какой-то причине не отработал.
(function () {
  try {
    var c = localStorage.getItem('ms-bg');
    if (c) document.documentElement.style.backgroundColor = c;
  } catch (e) {}
  setTimeout(function () {
    if (document.body) document.body.classList.add('ready');
  }, 1500);
})();
