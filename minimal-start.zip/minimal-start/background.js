'use strict';

// Клик по значку расширения открывает страницу настроек.
chrome.action.onClicked.addListener(() => {
  chrome.runtime.openOptionsPage();
});
