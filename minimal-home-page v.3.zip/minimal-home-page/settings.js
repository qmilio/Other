'use strict';

(function () {
  const $ = (id) => document.getElementById(id);

  let current = Store.normalizeSettings(null);
  let fonts = {};
  let bgImage = null;
  const controls = []; // { root, refresh(settings, fonts) }
  const rowRules = []; // { root, showIf(settings) }

  // ---------- вспомогательные ----------

  function h(tag, attrs, ...children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === false || v == null) continue;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else node.setAttribute(k, v === true ? '' : v);
    }
    children.flat().forEach((c) => {
      if (c == null) return;
      node.append(c.nodeType ? c : document.createTextNode(String(c)));
    });
    return node;
  }

  let idCounter = 0;
  const nextId = () => 'c' + ++idCounter;

  /** Единая точка записи: обновляем локальную копию сразу, в storage — через очередь. */
  function change(path, value) {
    Store.setByPath(current, path, value);
    updateVisibility();
    Store.setPath(path, value).catch((e) => console.error('Не удалось сохранить настройку', path, e));
  }

  function updateVisibility() {
    rowRules.forEach((r) => {
      r.root.hidden = !r.showIf(current);
    });
  }

  function register(def, built) {
    if (def.showIf) rowRules.push({ root: built.root, showIf: def.showIf });
    controls.push(built);
    return built.root;
  }

  const round = (v) => Math.round(v * 1000) / 1000;

  // ---------- типы контролов ----------

  function rangeControl(def) {
    const id = nextId();
    const range = h('input', { type: 'range', id, min: def.min, max: def.max, step: def.step });
    const num = h('input', { type: 'number', min: def.min, max: def.max, step: def.step, 'aria-label': def.label });
    const unit = h('span', { class: 'unit', text: def.unit || '' });
    const clamp = (v) => round(Math.min(def.max, Math.max(def.min, v)));

    range.addEventListener('input', () => {
      const v = clamp(Number(range.value));
      num.value = v;
      change(def.path, v);
    });
    num.addEventListener('change', () => {
      const raw = Number(num.value);
      if (num.value === '' || !Number.isFinite(raw)) {
        num.value = Store.getByPath(current, def.path);
        return;
      }
      const v = clamp(raw);
      num.value = v;
      range.value = v;
      change(def.path, v);
    });

    const root = h(
      'div',
      { class: 'row' },
      h('label', { for: id, text: def.label }),
      h('div', { class: 'range-line' }, range, num, unit),
      def.hint ? h('p', { class: 'hint', text: def.hint }) : null
    );
    return register(def, {
      root,
      refresh(s) {
        const v = Store.getByPath(s, def.path);
        if (document.activeElement !== range) range.value = v;
        if (document.activeElement !== num) num.value = v;
      }
    });
  }

  function colorControl(def) {
    const id = nextId();
    const picker = h('input', { type: 'color', id, 'aria-label': def.label });
    const text = h('input', {
      type: 'text',
      class: 'hex',
      maxlength: 24,
      spellcheck: 'false',
      autocomplete: 'off',
      placeholder: '#RRGGBB или rgb(r, g, b)',
      'aria-label': def.label + ' — HEX или RGB'
    });
    const readout = def.readout ? h('span', { class: 'readout' }) : null;
    const resetBtn = def.resetTo
      ? h('button', { type: 'button', class: 'link', text: 'Исходный' })
      : null;

    const showReadout = (hex) => {
      if (readout) readout.textContent = `rgb(${Store.hexToRgb(hex).join(', ')})`;
    };

    picker.addEventListener('input', () => {
      text.value = picker.value;
      text.classList.remove('invalid');
      showReadout(picker.value);
      change(def.path, picker.value);
    });
    text.addEventListener('input', () => {
      const hex = Store.parseColor(text.value);
      text.classList.toggle('invalid', !hex && text.value.trim() !== '');
      if (hex) {
        picker.value = hex;
        showReadout(hex);
        change(def.path, hex);
      }
    });
    text.addEventListener('change', () => {
      // при выходе из поля: корректное значение приводим к HEX, некорректное — откатываем
      text.value = Store.getByPath(current, def.path);
      text.classList.remove('invalid');
    });
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        const hex = def.resetTo;
        picker.value = hex;
        text.value = hex;
        text.classList.remove('invalid');
        showReadout(hex);
        change(def.path, hex);
      });
    }

    const root = h(
      'div',
      { class: 'row' },
      h('label', { for: id, text: def.label }),
      h('div', { class: 'color-line' }, picker, text, readout, resetBtn),
      def.hint ? h('p', { class: 'hint', text: def.hint }) : null
    );
    return register(def, {
      root,
      refresh(s) {
        const v = Store.getByPath(s, def.path);
        if (document.activeElement !== picker) picker.value = v;
        if (document.activeElement !== text) {
          text.value = v;
          text.classList.remove('invalid');
        }
        showReadout(v);
      }
    });
  }

  function checkControl(def) {
    const input = h('input', { type: 'checkbox' });
    input.addEventListener('change', () => change(def.path, input.checked));
    const root = h('div', { class: 'row' }, h('label', { class: 'check' }, input, def.label));
    return register(def, {
      root,
      refresh(s) {
        input.checked = !!Store.getByPath(s, def.path);
      }
    });
  }

  function selectControl(def) {
    const id = nextId();
    const select = h('select', { id });
    def.options.forEach((o) => select.append(h('option', { value: o.value, text: o.label })));
    select.addEventListener('change', () => change(def.path, select.value));
    const root = h(
      'div',
      { class: 'row' },
      h('label', { for: id, text: def.label }),
      select,
      def.hint ? h('p', { class: 'hint', text: def.hint }) : null
    );
    return register(def, {
      root,
      refresh(s) {
        select.value = String(Store.getByPath(s, def.path));
      }
    });
  }

  function fontControl(def) {
    const id = nextId();
    const select = h('select', { id });
    let builtKey = null;

    function rebuild(f) {
      const key = Object.keys(f).sort().map((k) => k + f[k].name).join('|');
      if (key === builtKey) return;
      builtKey = key;
      select.replaceChildren();
      const g1 = h('optgroup', { label: 'Встроенные' });
      Store.BUILTIN_FONTS.filter((x) => x.id !== 'system').forEach((x) => g1.append(h('option', { value: x.id, text: x.label })));
      g1.append(h('option', { value: 'system', text: 'Системный' }));
      select.append(g1);
      const ids = Object.keys(f);
      if (ids.length) {
        const g2 = h('optgroup', { label: 'Мои шрифты' });
        ids.forEach((fid) => g2.append(h('option', { value: 'custom:' + fid, text: f[fid].name })));
        select.append(g2);
      }
    }

    select.addEventListener('change', () => change(def.path, select.value));
    const root = h(
      'div',
      { class: 'row' },
      h('label', { for: id, text: def.label }),
      select,
      def.hint ? h('p', { class: 'hint', text: def.hint }) : null
    );
    return register(def, {
      root,
      refresh(s, f) {
        rebuild(f);
        const v = Store.getByPath(s, def.path);
        select.value = v;
        if (select.value !== v) select.value = 'system'; // шрифт удалён или недоступен
      }
    });
  }

  // ---------- фоновое фото ----------

  const MAX_PHOTO_INPUT = 30 * 1024 * 1024;
  const MAX_PHOTO_STORED = 3 * 1024 * 1024;

  /** Уменьшает и пережимает фото, чтобы оно уверенно помещалось в хранилище расширения. */
  async function preparePhoto(file) {
    const bmp = await createImageBitmap(file);
    try {
      for (const [maxDim, quality] of [[2560, 0.88], [1920, 0.8], [1280, 0.72]]) {
        const k = Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
        const w = Math.max(1, Math.round(bmp.width * k));
        const hh = Math.max(1, Math.round(bmp.height * k));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = hh;
        canvas.getContext('2d').drawImage(bmp, 0, 0, w, hh);
        const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/webp', quality));
        if (blob && blob.size <= MAX_PHOTO_STORED) return { blob, width: w, height: hh };
      }
    } finally {
      if (bmp.close) bmp.close();
    }
    throw new Error('too-big');
  }

  function bgImageControl(def) {
    const fileInput = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', hidden: true });
    const pick = h('button', { type: 'button', class: 'primary', text: 'Загрузить фото…' });
    const remove = h('button', { type: 'button', class: 'danger', text: 'Убрать фото', hidden: true });
    const thumb = h('div', { class: 'thumb', hidden: true });
    const info = h('p', { class: 'hint' });
    const msg = h('p', { class: 'msg', role: 'status' });

    const say = (t, err) => {
      msg.textContent = t;
      msg.className = 'msg ' + (err ? 'error' : 'ok');
    };

    pick.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', async () => {
      const file = fileInput.files && fileInput.files[0];
      fileInput.value = '';
      if (!file) return;
      if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
        say('Подходят изображения JPG, PNG и WebP.', true);
        return;
      }
      if (file.size > MAX_PHOTO_INPUT) {
        say('Файл больше 30 МБ. Выберите изображение поменьше.', true);
        return;
      }
      try {
        say('Обрабатываем фото…');
        const { blob, width, height } = await preparePhoto(file);
        const data = await readAsDataUrl(blob);
        await Store.setBgImage({ name: file.name.slice(0, 80), data, size: blob.size, width, height });
        change('background.mode', 'image');
        say('Фото установлено на фон.');
      } catch (e) {
        console.error(e);
        const quota = e && /quota/i.test(String(e.message));
        say(
          quota
            ? 'Не хватает места в хранилище расширения. Удалите ненужные шрифты и попробуйте снова.'
            : e && e.message === 'too-big'
              ? 'Не удалось достаточно сжать фото. Выберите изображение поменьше.'
              : 'Не удалось открыть изображение: файл повреждён или не поддерживается.',
          true
        );
      }
    });
    remove.addEventListener('click', async () => {
      await Store.clearBgImage();
      change('background.mode', 'color');
      say('Фото удалено, включён сплошной цвет.');
    });

    const root = h(
      'div',
      { class: 'row' },
      h('div', { class: 'label', text: 'Фоновое фото' }),
      thumb,
      info,
      h('div', { class: 'btn-line' }, pick, remove, fileInput),
      msg
    );
    return register(def, {
      root,
      refresh() {
        const has = !!bgImage;
        thumb.hidden = !has;
        remove.hidden = !has;
        if (has) thumb.style.backgroundImage = `url("${bgImage.data}")`;
        info.textContent = has
          ? `${bgImage.name} · ${bgImage.width}×${bgImage.height} · ${Math.max(1, Math.round(bgImage.size / 1024))} КБ`
          : 'Фото не выбрано — пока показывается сплошной цвет. Файл хранится только в вашем браузере и уменьшается до 2560 px.';
      }
    });
  }

  const BUILDERS = { bgimage: bgImageControl, range: rangeControl, color: colorControl, check: checkControl, select: selectControl, font: fontControl };

  // ---------- описание разделов ----------

  const isCenter = (s) => s.position.mode === 'center';
  const isManual = (s) => s.position.mode === 'manual';

  const SECTIONS = [
    {
      id: 'clock',
      title: 'Часы',
      resetKeys: ['clock'],
      controls: [
        { type: 'font', path: 'clock.fontId', label: 'Шрифт', hint: 'Свои шрифты загружаются в разделе «Общие».' },
        { type: 'range', path: 'clock.size', label: 'Размер', min: 40, max: 400, step: 1, unit: 'px', hint: 'На узких окнах размер уменьшается автоматически.' },
        { type: 'range', path: 'clock.weight', label: 'Толщина', min: 100, max: 900, step: 10, hint: 'Работает для вариативных шрифтов (все встроенные). У обычных файлов шрифта начертание одно.' },
        { type: 'range', path: 'clock.letterSpacing', label: 'Межбуквенный интервал', min: -0.1, max: 0.5, step: 0.005, unit: 'em' },
        { type: 'color', path: 'clock.color', label: 'Цвет текста' },
        {
          type: 'select',
          path: 'clock.format',
          label: 'Формат времени',
          options: [
            { value: '24', label: '24-часовой' },
            { value: '12', label: '12-часовой (AM/PM)' }
          ]
        },
        { type: 'check', path: 'clock.showSeconds', label: 'Показывать секунды' },
        { type: 'check', path: 'clock.showDate', label: 'Показывать дату' },
        { type: 'range', path: 'clock.dateSize', label: 'Размер даты', min: 12, max: 80, step: 1, unit: 'px', showIf: (s) => s.clock.showDate }
      ]
    },
    {
      id: 'shadow',
      title: 'Тень часов',
      resetKeys: ['shadow'],
      controls: [
        { type: 'check', path: 'shadow.enabled', label: 'Включить тень' },
        { type: 'color', path: 'shadow.color', label: 'Цвет тени', showIf: (s) => s.shadow.enabled },
        { type: 'range', path: 'shadow.opacity', label: 'Интенсивность', min: 0, max: 100, step: 1, unit: '%', showIf: (s) => s.shadow.enabled },
        { type: 'range', path: 'shadow.blur', label: 'Размытие', min: 0, max: 100, step: 1, unit: 'px', showIf: (s) => s.shadow.enabled },
        { type: 'range', path: 'shadow.x', label: 'Смещение по горизонтали', min: -60, max: 60, step: 1, unit: 'px', showIf: (s) => s.shadow.enabled },
        { type: 'range', path: 'shadow.y', label: 'Смещение по вертикали', min: -60, max: 60, step: 1, unit: 'px', showIf: (s) => s.shadow.enabled }
      ]
    },
    {
      id: 'position',
      title: 'Положение',
      resetKeys: ['position'],
      controls: [
        {
          type: 'select',
          path: 'position.mode',
          label: 'Выравнивание',
          options: [
            { value: 'center', label: 'По центру экрана' },
            { value: 'manual', label: 'Ручное позиционирование' }
          ]
        },
        { type: 'range', path: 'position.offsetX', label: 'Смещение по горизонтали', min: -45, max: 45, step: 0.5, unit: '%', hint: 'От центра, в процентах ширины экрана.', showIf: isCenter },
        { type: 'range', path: 'position.offsetY', label: 'Смещение по вертикали', min: -45, max: 45, step: 0.5, unit: '%', hint: 'От центра, в процентах высоты экрана.', showIf: isCenter },
        { type: 'range', path: 'position.manualX', label: 'Положение по горизонтали', min: 0, max: 100, step: 0.5, unit: '%', hint: 'Положение центра часов слева направо.', showIf: isManual },
        { type: 'range', path: 'position.manualY', label: 'Положение по вертикали', min: 0, max: 100, step: 0.5, unit: '%', hint: 'Положение центра часов сверху вниз.', showIf: isManual }
      ]
    },
    {
      id: 'background',
      title: 'Фон',
      resetKeys: ['background'],
      controls: [
        {
          type: 'select',
          path: 'background.mode',
          label: 'Тип фона',
          options: [
            { value: 'color', label: 'Сплошной цвет' },
            { value: 'image', label: 'Своё фото' }
          ]
        },
        {
          type: 'color',
          path: 'background.color',
          label: 'Цвет фона',
          readout: true,
          resetTo: Store.DEFAULTS.background.color,
          hint: 'Вводите HEX (#1a1a1a) или RGB (26, 26, 26). Цвет также виден, пока фото загружается.',
          showIf: (s) => s.background.mode === 'color'
        },
        { type: 'bgimage', showIf: (s) => s.background.mode === 'image' },
        {
          type: 'range',
          path: 'background.blur',
          label: 'Размытие фона',
          min: 0,
          max: 60,
          step: 1,
          unit: 'px',
          hint: 'Размывает весь фон-фото целиком. 0 — без размытия.',
          showIf: (s) => s.background.mode === 'image'
        }
      ]
    },
    {
      id: 'bookmarks',
      title: 'Закладки',
      resetKeys: ['bookmarks'],
      resetLabel: 'Сбросить оформление',
      controls: [
        { type: 'range', path: 'bookmarks.fontSize', label: 'Размер текста', min: 10, max: 32, step: 1, unit: 'px' },
        { type: 'color', path: 'bookmarks.color', label: 'Цвет текста' },
        { type: 'range', path: 'bookmarks.opacity', label: 'Заметность в покое', min: 10, max: 100, step: 1, unit: '%', hint: 'При наведении закладка становится полностью яркой.' },
        { type: 'range', path: 'bookmarks.gap', label: 'Расстояние между закладками', min: 8, max: 80, step: 1, unit: 'px' },
        { type: 'range', path: 'bookmarks.weight', label: 'Толщина текста', min: 300, max: 700, step: 50 },
        { type: 'check', path: 'bookmarks.sameFont', label: 'Шрифт как у часов' },
        {
          type: 'select',
          path: 'bookmarks.position',
          label: 'Положение на странице',
          options: [
            { value: 'bottom', label: 'Внизу' },
            { value: 'top', label: 'Вверху' }
          ]
        },
        {
          type: 'select',
          path: 'bookmarks.align',
          label: 'Расположение',
          options: [
            { value: 'left', label: 'Слева' },
            { value: 'center', label: 'По центру' },
            { value: 'right', label: 'Справа' }
          ]
        }
      ],
      extra: buildBookmarkManager
    },
    {
      id: 'config',
      title: 'Конфигурации',
      noReset: true,
      controls: [],
      extra: buildConfigCard
    },
    {
      id: 'general',
      title: 'Общие',
      noReset: true,
      controls: [],
      extra: buildGeneral
    }
  ];

  // ---------- менеджер закладок ----------

  function buildBookmarkManager() {
    const title = h('input', { type: 'text', maxlength: 60, placeholder: 'Название (необязательно)', 'aria-label': 'Название закладки', autocomplete: 'off' });
    const url = h('input', { type: 'text', placeholder: 'Адрес: example.com', 'aria-label': 'Адрес сайта', spellcheck: 'false', autocomplete: 'off' });
    const useColor = h('input', { type: 'checkbox' });
    const color = h('input', { type: 'color', value: '#f2f2f2', disabled: true, 'aria-label': 'Цвет закладки' });
    const saveBtn = h('button', { type: 'submit', class: 'primary', text: 'Добавить' });
    const cancelBtn = h('button', { type: 'button', text: 'Отмена', hidden: true });
    const msg = h('p', { class: 'msg error', role: 'alert' });
    const list = h('ul', { class: 'bm-list' });
    const heading = h('h3', { text: 'Мои закладки' });
    let editingId = null;
    let renderedKey = null;

    useColor.addEventListener('change', () => {
      color.disabled = !useColor.checked;
    });

    function resetForm() {
      editingId = null;
      title.value = '';
      url.value = '';
      useColor.checked = false;
      color.disabled = true;
      color.value = current.bookmarks.color;
      saveBtn.textContent = 'Добавить';
      cancelBtn.hidden = true;
      msg.textContent = '';
      heading.textContent = 'Мои закладки';
    }

    function startEdit(item) {
      editingId = item.id;
      title.value = item.title;
      url.value = item.url;
      useColor.checked = !!item.color;
      color.disabled = !item.color;
      color.value = item.color || current.bookmarks.color;
      saveBtn.textContent = 'Сохранить изменения';
      cancelBtn.hidden = false;
      msg.textContent = '';
      url.focus();
    }

    const form = h(
      'form',
      { class: 'bm-form', novalidate: true },
      title,
      url,
      h('label', { class: 'check' }, useColor, 'Свой цвет', color),
      h('div', { class: 'btn-line', style: 'justify-content:flex-end' }, cancelBtn, saveBtn),
      h('div', { class: 'full' }, msg)
    );
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const clean = Store.normalizeUrl(url.value);
      if (!clean) {
        msg.textContent = 'Введите корректный адрес, например example.com или https://example.com';
        url.focus();
        return;
      }
      const dup = current.items.find((i) => i.url === clean && i.id !== editingId);
      if (dup) {
        msg.textContent = `Такая закладка уже есть: «${dup.title}»`;
        return;
      }
      try {
        await Store.saveBookmark({ id: editingId, title: title.value, url: clean, color: useColor.checked ? color.value : '' });
        resetForm();
      } catch (err) {
        msg.textContent = 'Не удалось сохранить закладку.';
        console.error(err);
      }
    });
    cancelBtn.addEventListener('click', resetForm);

    function renderList() {
      const key = JSON.stringify(current.items);
      if (key === renderedKey) return;
      renderedKey = key;
      list.replaceChildren();
      if (!current.items.length) {
        list.append(h('li', { class: 'empty', text: 'Закладок пока нет. Добавьте первую выше.' }));
        return;
      }
      current.items.forEach((item, i) => {
        const nameLine = h('span', { class: 'name' }, item.color ? h('span', { class: 'swatch', style: `background:${item.color}` }) : null, item.title);
        const info = h('div', { style: 'min-width:0' }, nameLine, h('span', { class: 'url', text: item.url }));
        const up = h('button', { type: 'button', title: 'Выше', 'aria-label': 'Переместить выше', text: '↑', disabled: i === 0 });
        const down = h('button', { type: 'button', title: 'Ниже', 'aria-label': 'Переместить ниже', text: '↓', disabled: i === current.items.length - 1 });
        const edit = h('button', { type: 'button', title: 'Изменить', 'aria-label': 'Изменить закладку', text: '✎' });
        const del = h('button', { type: 'button', title: 'Удалить', 'aria-label': 'Удалить закладку', text: '✕' });
        up.addEventListener('click', () => Store.moveBookmark(item.id, i - 1));
        down.addEventListener('click', () => Store.moveBookmark(item.id, i + 1));
        edit.addEventListener('click', () => startEdit(item));
        del.addEventListener('click', () => {
          if (!confirm(`Удалить закладку «${item.title}»?`)) return;
          if (editingId === item.id) resetForm();
          Store.deleteBookmark(item.id);
        });
        list.append(h('li', {}, info, h('div', { class: 'tools' }, up, down, edit, del)));
      });
    }

    const card = h('div', { class: 'card' }, heading, form, list);
    controls.push({
      root: card,
      refresh() {
        renderList();
      }
    });
    return card;
  }

  // ---------- конфигурации: экспорт и импорт ----------

  const MAX_CONFIG_BYTES = 40 * 1024 * 1024;

  function readAsText(blob) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result));
      fr.onerror = () => reject(fr.error || new Error('read-failed'));
      fr.readAsText(blob);
    });
  }

  function buildConfigCard() {
    const msg = h('p', { class: 'msg', role: 'status' });
    const say = (t, err) => {
      msg.textContent = t;
      msg.className = 'msg ' + (err ? 'error' : 'ok');
    };

    // --- экспорт ---
    const cbBm = h('input', { type: 'checkbox', checked: true });
    const cbFonts = h('input', { type: 'checkbox', checked: true });
    const cbPhoto = h('input', { type: 'checkbox', checked: true });
    const lbBm = h('span', { text: 'Закладки' });
    const lbFonts = h('span', { text: 'Мои шрифты' });
    const lbPhoto = h('span', { text: 'Фоновое фото' });
    const exportBtn = h('button', { type: 'button', class: 'primary', text: 'Экспортировать в файл' });

    exportBtn.addEventListener('click', async () => {
      try {
        const cfg = await Store.exportConfig({ bookmarks: cbBm.checked, fonts: cbFonts.checked, photo: cbPhoto.checked });
        const blob = new Blob([JSON.stringify(cfg, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const name = `minimal-start-config-${new Date().toISOString().slice(0, 10)}.json`;
        const a = h('a', { href: url, download: name });
        document.body.append(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 10000);
        say(`Конфигурация сохранена: ${name}`);
      } catch (e) {
        console.error(e);
        say('Не удалось создать файл конфигурации.', true);
      }
    });

    // --- импорт ---
    const fileInput = h('input', { type: 'file', accept: '.json,application/json', hidden: true });
    const importBtn = h('button', { type: 'button', text: 'Импортировать из файла…' });
    importBtn.addEventListener('click', () => fileInput.click());

    const dlg = $('import-dialog');
    const impErr = $('import-error');
    let pending = null;

    fileInput.addEventListener('change', async () => {
      const file = fileInput.files && fileInput.files[0];
      fileInput.value = '';
      if (!file) return;
      if (file.size > MAX_CONFIG_BYTES) {
        say('Файл слишком большой для конфигурации (больше 40 МБ).', true);
        return;
      }
      try {
        const cfg = Store.parseConfig(await readAsText(file));
        pending = cfg;
        const fontCount = Object.keys(cfg.fonts).length;
        const when = cfg.exportedAt ? ` · ${new Date(cfg.exportedAt).toLocaleString()}` : '';
        $('import-info').textContent = `${file.name}${when}`;
        $('imp-style').checked = true;
        $('imp-bm-row').hidden = !cfg.hasItems;
        $('imp-bm').checked = cfg.hasItems;
        $('imp-bm-mode').value = 'replace';
        $('imp-bm-label').textContent = `Закладки (${cfg.settings.items.length})`;
        $('imp-fonts-row').hidden = !fontCount;
        $('imp-fonts').checked = fontCount > 0;
        $('imp-fonts-label').textContent = `Шрифты (${fontCount})`;
        $('imp-photo-row').hidden = !cfg.photo;
        $('imp-photo').checked = !!cfg.photo;
        impErr.textContent = '';
        say('');
        dlg.showModal();
      } catch (e) {
        const text = {
          'not-json': 'Файл не является корректным JSON.',
          'not-config': 'Это не файл конфигурации Minimal Start.',
          'too-new': 'Конфигурация создана в более новой версии расширения.'
        }[e && e.message];
        if (!text) console.error(e);
        say(text || 'Не удалось прочитать файл.', true);
      }
    });

    $('import-cancel').addEventListener('click', () => dlg.close());
    dlg.addEventListener('click', (e) => {
      if (e.target === dlg) dlg.close();
    });
    $('import-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!pending) return dlg.close();
      try {
        await Store.applyConfig(pending, {
          style: $('imp-style').checked,
          bookmarks: $('imp-bm').checked && pending.hasItems ? $('imp-bm-mode').value : 'skip',
          fonts: $('imp-fonts').checked,
          photo: $('imp-photo').checked
        });
        current = await Store.getSettings();
        fonts = await Store.getFonts();
        bgImage = await Store.getBgImage();
        refreshAll();
        pending = null;
        dlg.close();
        say('Конфигурация применена.');
      } catch (err) {
        console.error(err);
        const quota = err && /quota/i.test(String(err.message));
        impErr.textContent = quota
          ? 'Не хватает места в хранилище расширения. Снимите «Шрифты» или «Фоновое фото» либо удалите ненужное.'
          : 'Не удалось применить конфигурацию.';
      }
    });

    const card = h(
      'div',
      { class: 'card' },
      h('h3', { text: 'Экспорт' }),
      h('p', { class: 'hint', text: 'Сохраните текущие настройки в файл, чтобы перенести их на другой компьютер или быстро вернуться к нужному виду. Отметьте, что включить в файл.' }),
      h('label', { class: 'check' }, cbBm, lbBm),
      h('label', { class: 'check' }, cbFonts, lbFonts),
      h('label', { class: 'check' }, cbPhoto, lbPhoto),
      h('div', { class: 'btn-line' }, exportBtn)
    );
    const importCard = h(
      'div',
      { class: 'card' },
      h('h3', { text: 'Импорт' }),
      h('p', { class: 'hint', text: 'Выберите файл конфигурации. Перед применением вы сможете выбрать, какие части загрузить.' }),
      h('div', { class: 'btn-line' }, importBtn, fileInput),
      msg
    );

    controls.push({
      root: card,
      refresh() {
        const n = current.items.length;
        const fc = Object.keys(fonts).length;
        lbBm.textContent = `Закладки (${n})`;
        lbFonts.textContent = `Мои шрифты (${fc})`;
        lbPhoto.textContent = bgImage ? 'Фоновое фото' : 'Фоновое фото (не загружено)';
        cbFonts.disabled = !fc;
        cbPhoto.disabled = !bgImage;
        cbBm.disabled = !n;
      }
    });
    return [card, importCard];
  }

  // ---------- «Общие»: шрифты, домашняя страница, сброс ----------

  const MAX_FONT_BYTES = 3 * 1024 * 1024;
  const FONT_TYPES = {
    woff2: { mime: 'font/woff2', label: 'WOFF2' },
    woff: { mime: 'font/woff', label: 'WOFF' },
    ttf: { mime: 'font/ttf', label: 'TTF' },
    otf: { mime: 'font/otf', label: 'OTF' }
  };

  function sniffFontFormat(buf) {
    const b = new Uint8Array(buf, 0, Math.min(4, buf.byteLength));
    const tag = String.fromCharCode(...b);
    if (tag === 'wOF2') return 'woff2';
    if (tag === 'wOFF') return 'woff';
    if (tag === 'OTTO') return 'otf';
    if ((b[0] === 0 && b[1] === 1 && b[2] === 0 && b[3] === 0) || tag === 'true') return 'ttf'; // TrueType (в .ttf и .otf)
    return null;
  }

  function readAsDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(fr.result);
      fr.onerror = () => reject(fr.error || new Error('read-failed'));
      fr.readAsDataURL(blob);
    });
  }

  function buildGeneral() {
    // --- шрифты ---
    const fileInput = h('input', { type: 'file', accept: '.woff,.woff2,.ttf,.otf', hidden: true });
    const pickBtn = h('button', { type: 'button', class: 'primary', text: 'Загрузить шрифт…' });
    const fontMsg = h('p', { class: 'msg', role: 'status' });
    const fontList = h('ul', { class: 'bm-list' });
    let fontKey = null;

    function say(text, isError) {
      fontMsg.textContent = text;
      fontMsg.className = 'msg ' + (isError ? 'error' : 'ok');
    }

    pickBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', async () => {
      const file = fileInput.files && fileInput.files[0];
      fileInput.value = '';
      if (!file) return;
      try {
        const ext = (file.name.split('.').pop() || '').toLowerCase();
        if (!FONT_TYPES[ext]) {
          say('Неподдерживаемый формат. Подходят файлы WOFF, WOFF2, TTF и OTF.', true);
          return;
        }
        if (file.size > MAX_FONT_BYTES) {
          say('Файл больше 3 МБ. Выберите шрифт полегче (лучше WOFF2).', true);
          return;
        }
        say('Проверяем шрифт…');
        const buf = await file.arrayBuffer();
        const real = sniffFontFormat(buf);
        const okSig = real && (real === ext || (real === 'ttf' && ext === 'otf'));
        if (!okSig) {
          say('Файл не похож на шрифт: содержимое не соответствует расширению .' + ext + '.', true);
          return;
        }
        // пробная загрузка: браузер сам скажет, если шрифт повреждён
        const testFace = new FontFace('MSTest-' + Store.uid(), buf);
        await testFace.load();

        const data = await readAsDataUrl(new Blob([buf], { type: FONT_TYPES[ext].mime }));
        const name = file.name.replace(/\.[^.]+$/, '').slice(0, 60) || 'Мой шрифт';
        const id = await Store.addFont({ name, format: ext, data, size: file.size });
        change('clock.fontId', 'custom:' + id);
        say(`Шрифт «${name}» добавлен и выбран для часов.`);
      } catch (e) {
        console.error(e);
        const quota = e && /quota/i.test(String(e.message));
        say(
          quota
            ? 'Не хватает места в хранилище расширения. Удалите ненужные шрифты и попробуйте снова.'
            : 'Не удалось загрузить шрифт: файл повреждён или не поддерживается браузером.',
          true
        );
      }
    });

    function renderFonts() {
      const key = Object.keys(fonts).sort().join('|');
      if (key === fontKey) return;
      fontKey = key;
      fontList.replaceChildren();
      const ids = Object.keys(fonts);
      if (!ids.length) {
        fontList.append(h('li', { class: 'empty', text: 'Своих шрифтов пока нет.' }));
        return;
      }
      ids.forEach((id) => {
        const f = fonts[id];
        const kb = Math.max(1, Math.round((f.size || 0) / 1024));
        const del = h('button', { type: 'button', title: 'Удалить шрифт', 'aria-label': 'Удалить шрифт ' + f.name, text: '✕' });
        del.addEventListener('click', async () => {
          if (!confirm(`Удалить шрифт «${f.name}»?`)) return;
          await Store.removeFont(id);
          say('Шрифт удалён.');
        });
        fontList.append(h('li', {}, h('div', { style: 'min-width:0' }, h('span', { class: 'name', text: f.name }), h('span', { class: 'url', text: `${(FONT_TYPES[f.format] || {}).label || f.format} · ${kb} КБ` })), h('div', { class: 'tools' }, del)));
      });
    }
    const fontsCard = h(
      'div',
      { class: 'card' },
      h('h3', { text: 'Мои шрифты' }),
      h('p', { class: 'hint', text: 'Форматы WOFF, WOFF2, TTF, OTF до 3 МБ. Файлы хранятся только в вашем браузере.' }),
      h('div', { class: 'btn-line' }, pickBtn, fileInput),
      fontMsg,
      fontList
    );
    controls.push({ root: fontsCard, refresh: renderFonts });

    // --- домашняя страница ---
    const homeUrl = chrome.runtime.getURL('newtab.html');
    const homeInput = h('input', { type: 'text', readonly: true, value: homeUrl, 'aria-label': 'Адрес стартовой страницы' });
    const copyBtn = h('button', { type: 'button', text: 'Копировать' });
    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(homeUrl);
        copyBtn.textContent = 'Скопировано';
      } catch (e) {
        homeInput.select();
        copyBtn.textContent = 'Выделено — Ctrl+C';
      }
      setTimeout(() => (copyBtn.textContent = 'Копировать'), 2000);
    });
    const homeCard = h(
      'div',
      { class: 'card' },
      h('h3', { text: 'Домашняя страница' }),
      h('p', { class: 'hint', text: 'Расширение заменяет страницу новой вкладки. Чтобы открывать её же по кнопке «Домой», вставьте этот адрес в настройках браузера (Chrome: «Внешний вид» → «Главная страница»; Edge: «Запуск, главная страница и новые вкладки»). Принимает ли браузер такой адрес — зависит от самого браузера.' }),
      h('div', { class: 'color-line' }, homeInput, copyBtn)
    );

    // --- сброс ---
    const resetBtn = h('button', { type: 'button', class: 'danger', text: 'Сбросить все настройки…' });
    resetBtn.addEventListener('click', () => {
      $('reset-bookmarks').checked = false;
      $('reset-fonts').checked = false;
      $('reset-photo').checked = false;
      $('reset-dialog').showModal();
    });
    const resetCard = h(
      'div',
      { class: 'card' },
      h('h3', { text: 'Сброс' }),
      h('p', { class: 'hint', text: 'Каждый раздел можно сбросить отдельно кнопкой в его заголовке. Здесь — сброс всего сразу, с подтверждением.' }),
      h('div', { class: 'btn-line' }, resetBtn)
    );

    return [fontsCard, homeCard, resetCard];
  }

  // ---------- сборка страницы ----------

  function buildPage() {
    const nav = $('nav');
    const host = $('sections');

    SECTIONS.forEach((sec) => {
      const btn = h('button', { type: 'button', text: sec.title, 'data-id': sec.id });
      btn.addEventListener('click', () => showSection(sec.id));
      nav.append(btn);

      const head = h('div', { class: 'sect-head' }, h('h2', { text: sec.title }));
      if (!sec.noReset) {
        const rb = h('button', { type: 'button', class: 'link', text: sec.resetLabel || 'Сбросить раздел' });
        rb.addEventListener('click', () => {
          if (confirm(`Вернуть раздел «${sec.title}» к значениям по умолчанию? Остальные настройки не изменятся.`)) {
            Store.resetKeys(sec.resetKeys).then((s) => {
              current = s;
              refreshAll();
            });
          }
        });
        head.append(rb);
      }

      const section = h('section', { class: 'sect', 'data-id': sec.id, hidden: true }, head);
      if (sec.controls.length) {
        const card = h('div', { class: 'card' });
        sec.controls.forEach((def) => card.append(BUILDERS[def.type](def)));
        section.append(card);
      }
      if (sec.extra) {
        const extra = sec.extra();
        (Array.isArray(extra) ? extra : [extra]).forEach((n) => section.append(n));
      }
      host.append(section);
    });

    const initial = location.hash.slice(1);
    showSection(SECTIONS.some((s) => s.id === initial) ? initial : SECTIONS[0].id);
  }

  function showSection(id) {
    document.querySelectorAll('section.sect').forEach((s) => {
      s.hidden = s.dataset.id !== id;
    });
    document.querySelectorAll('#nav button').forEach((b) => {
      b.setAttribute('aria-current', String(b.dataset.id === id));
    });
    history.replaceState(null, '', '#' + id);
  }

  function refreshAll() {
    controls.forEach((c) => c.refresh(current, fonts));
    updateVisibility();
  }

  // ---------- предпросмотр: страница в реальном масштабе экрана, уменьшенная до ширины колонки ----------

  function setupPreview() {
    const wrap = $('preview-wrap');
    const frame = $('preview');
    const W = Math.max(window.screen.width || 1280, 800);
    const H = Math.max((window.screen.height || 800) - 140, 500);
    frame.style.width = W + 'px';
    frame.style.height = H + 'px';
    wrap.style.aspectRatio = `${W} / ${H}`;
    const fit = () => {
      if (wrap.clientWidth) frame.style.transform = `scale(${wrap.clientWidth / W})`;
    };
    if (typeof ResizeObserver !== 'undefined') new ResizeObserver(fit).observe(wrap);
    window.addEventListener('resize', fit);
    fit();
  }

  // ---------- диалог полного сброса ----------

  function setupResetDialog() {
    const dlg = $('reset-dialog');
    $('reset-cancel').addEventListener('click', () => dlg.close());
    dlg.addEventListener('click', (e) => {
      if (e.target === dlg) dlg.close();
    });
    $('reset-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        await Store.resetAll({
          bookmarks: $('reset-bookmarks').checked,
          fonts: $('reset-fonts').checked,
          photo: $('reset-photo').checked
        });
        current = await Store.getSettings();
        fonts = await Store.getFonts();
        bgImage = await Store.getBgImage();
        refreshAll();
      } catch (err) {
        console.error('Не удалось сбросить настройки', err);
      }
      dlg.close();
    });
  }

  // ---------- запуск ----------

  Store.onChange(async (changes) => {
    if (changes[Store.FONTS_KEY]) fonts = await Store.getFonts();
    if (changes[Store.BG_KEY]) bgImage = await Store.getBgImage();
    if (changes[Store.SETTINGS_KEY]) current = Store.normalizeSettings(changes[Store.SETTINGS_KEY].newValue);
    refreshAll();
  });

  (async function init() {
    try {
      [current, fonts, bgImage] = await Promise.all([Store.getSettings(), Store.getFonts(), Store.getBgImage()]);
    } catch (e) {
      console.error('Не удалось прочитать настройки', e);
    }
    buildPage();
    setupPreview();
    setupResetDialog();
    refreshAll();
  })();
})();
